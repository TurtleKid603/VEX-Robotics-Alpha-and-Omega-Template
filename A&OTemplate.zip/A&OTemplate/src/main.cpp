//Setup Stuff
  /*----------------------------------------------------------------------------*/
  /*                                                                            */
  /*    Module:       main.cpp                                                  */
  /*    Author:       BJARobotics                                               */
  /*    Created:      Fri Oct 24 2025                                           */
  /*    Description:  V5 project                                                */
  /*                                                                            */
  /*----------------------------------------------------------------------------*/

#include "vex.h"

  // ---- START VEXCODE CONFIGURED DEVICES ----
  // Robot Configuration:
  // [Name]               [Type]        [Port(s)]
  // Controller1          controller                    
  // ---- END VEXCODE CONFIGURED DEVICES ----
  competition Competition;

  using namespace vex;

//Requirements:
  //Having 6 motors isn't a requirement but this template is ment for 6 motors (3 on each side)
  //Give me credit in your engineering notebook (Team 33249A Alpha and Omega)
  //Send me feedback at 33249alphaomega@gmail.com
    //Be nice
//---------------STEP1---------------//
//Configuring Motors
  //Configure your motors in the in the side bar on the top right next to the question mark and comment bubble
  //Instead of selecting "Drivetrain" select "Motor"
  //Select the Port that corresponds with a the first motor on the left side of your drivetrain
  //Select the type of motor you have: Red, Green, or Blue
  //Do not change your motor from "Normal" to "Reverse" 
  //Select done
  //Repeat this process for the other two motors on the left side of your drivetrain
  /*Repeat this process for the three motors on the right side of you're drivetrain,
  except that you need to click the switch from "Normal" to "Reverse" before you select done*/
//---------------STEP2---------------//
//List the left motor's names in the parenthesis separated by commas below
  //Example: motor_group LD = motor_group(Motor1,Motor2,Motor3);
  //If you renamed your motor something else just input that name
  //Example: If you named you're Motors L1, L2, and L3 then you would input "motor_group LD = motor_group(L1,L2,L3);"
  motor_group LD = motor_group();
//Do the same thing with the right side motors in the parenthesis below
  //Example: motor_group RD = motor_group(Motor4,Motor5,Motor6);
  //Another Example: motor_group RD = motor_group(R1,R2,R3);
  motor_group RD = motor_group();
//List all the motors in your drivetrain in the parenthesis separated by commas below
  //Example: motor_group FD = motor_group(Motor1,Motor2,Motor3,Motor4,Motor5,Motor6);
  //Another Example: motor_group FD = motor_group(L1,L2,L3,R1,R2,R3);
  motor_group FD = motor_group();
//---------------STEP3---------------//
//Type the number of what you want youre drive controls to be
  //If you look at you're controller you can see which Axises I am refering to
  //1: Moving Axis 3 forward makes the bot go forward and moving Axis 4 to the side makes the bot go the same direction
    //arcade
  //2: Moving Axis 2 forward makes the bot go forward and moving Axis 1 to the side makes the bot go the same direction
    //arcade
  //3: Moving Axis 3 forward makes the bot go forward and moving Axis 1 to the side makes the bot go the same direction
    //split arcade
  //4: Moving Axis 2 forward makes the bot go forward and moving Axis 4 to the side makes the bot go the same direction
    //split arcade
  //5: Moving Axis 3 forward makes the left side of the bot go forward and moving Axis 2 makes the right side of the bot go forward
    //tank drive
  //0:For If you don't want a drivecode for some reason
  //Example: int drivetype = 3;
  int drivetype = 1;


//User Control Stuff
  void usercontrol(void){ //don't change this line
  
  while(1){ //don't change this line
    //Put your if-loops and stuff here

     //Ignore this part and don't change it or else stuff won't work
     void func_drivetype(int drivetype);
     wait(20,msec);
    }
  }


//Functions
  //Ingore all of this stuff and DONT CHANGE IT up until "STEP5"
  //If you change it this code wont work


 void FDF(int per, float snds){
    FD.spin(forward, per, pct);
    wait(snds,sec);
    FD.stop();
  }
  void FDB(int per, float snds){
    FD.spin(reverse,per,pct);
    wait(snds,sec);
    FD.stop();
  }

  void FDL(int per, float snds){
    LD.spin(reverse,per,pct);
    RD.spin(forward,per,pct);
    wait(snds,sec);
    FD.stop();
  }

  void FDR(int per, float snds){
    RD.spin(reverse,per,pct);
    LD.spin(forward,per,pct);
    wait(snds,sec);
    FD.stop();
  }
//
//---------------STEP4---------------//
//-----------VERY-OPTIONAL-----------//
  void autonomous(void){
  //How to Code Autonomous (You don't have to read all of this)
    //THIS IS VERY OPTIONAL AND TIME CONSUMING
    //1:Functions and how they work
      //FDF(): Drives Drivetrain Forward
        //FDF([percentage],[time]);
          //Spins Drivetrain forward at a percentage for a specified time
        //Example: FDF(30,2);
          //spins Drivetrain at 30% velocity for 2 seconds
        //Another Example: FDF(24,1.1);
          //spins Drivetrain at 24% velocity for 1.1 seconds
      //FDB(): Drives Drivetrain Backwards
        //The same as FDF but it goes backwards instead of forwards
      //FDL(): Turns Drivetrain Left
        //FDF([percentage],[time]);
          //Turns Drivetrain left at a percentage for a specified time
        //Example: FDF(45,0.64);
          //Turns Drivetrain left at 45% voltage for 0.64 seconds
      //FDR(): Turns Drivetrain Right
        //The same as FDL but it turns right instead of left
    //2:Normal Non-Fuction Things and how they work
      //wait(): Waits a time
        //wait([time],[time units]);
          //waits for a specified time for a unit of time: seconds or milliseconds
        //Example: wait(1,sec);
          //waits for 1 second
      //MOTOR.spin(): Spins a Motor
        //MOTOR.spin([direction],[percentage],pct);
          //Spins a Motor a direction at a specified percentage
        //Example: Motor1.spin(reverse,20,pct);
          //Spins Motor1 backwards at 20% voltage
        //Another Example: L1.spin(forward,100,pct);
          //Spins L1 (a motor) forwards at 100% voltage
      //PISTON.set(): Makes a Piston Turn On or Off
        //Example: PistonA.set(false);
          //Turns PistonA On (Extends it)
        //Another Example: LWM.set(false);
          //Turns LWM Off (Contracts it)
    //3: A Few More Things
      //Put a semicolon, ";", after every line
      //If something is highlighted red that means you enter it in wrong (or I messed up)
      //All the Green stuff doesn't matter so if you want to delete it you can but you might want to keep it for future reference
        //Don't delete any color other than green
  /////////////////////////////////////////////////////////////////////////////////
  //You're code here:

  
  }
//Extra Stuff
  //Ingore all of this stuff and DONT CHANGE IT AT ALL
  //If you change it this code wont work
  void func_drivetype(int drivetype){
   switch(drivetype){
     case 0:
     break;
     case 1:
     LD.spin(forward,(Controller1.Axis3.value()+Controller1.Axis4.value()),pct);
     RD.spin(forward,(Controller1.Axis3.value()-Controller1.Axis4.value()),pct);
     break;
     case 2:
     LD.spin(forward,(Controller1.Axis2.value()+Controller1.Axis1.value()),pct);
     RD.spin(forward,(Controller1.Axis2.value()-Controller1.Axis1.value()),pct);
     break;
     case 3:
     LD.spin(forward,(Controller1.Axis3.value()+Controller1.Axis1.value()),pct);
     RD.spin(forward,(Controller1.Axis3.value()-Controller1.Axis1.value()),pct);
     break;
     case 4:
     LD.spin(forward,(Controller1.Axis2.value()+Controller1.Axis4.value()),pct);
     RD.spin(forward,(Controller1.Axis2.value()-Controller1.Axis4.value()),pct);
     break;
     case 5:
     LD.spin(forward,Controller1.Axis3.value(),pct);
     RD.spin(forward,Controller1.Axis2.value(),pct);
     break;
   }
  }

 int main() {
    vexcodeInit();
    Competition.autonomous(autonomous);
    Competition.drivercontrol(usercontrol);
  }

//If you are reading this, Subscribe because this took a long time to make 
//https://www.youtube.com/@33249A
//--------------THE-END--------------//